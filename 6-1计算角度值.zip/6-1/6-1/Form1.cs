﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _6_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        delegate void TriFunc(double Angle);
        public double TransAngle(double a)
        {
            a = a * Math.PI / 180;
            return a;
        }
        public void SinFunc(double ang)
        {
            ang = TransAngle(ang);
            lblResult.Text = "正弦值为：" + Math.Sin(ang).ToString("f4") + "\n\n";
        }
        public void CosFunc(double ang)
        {
            ang = TransAngle(ang);
            lblResult.Text=lblResult.Text+ "余弦值为：" + Math.Cos(ang).ToString("f4") + "\n\n";
        }
        public void TanFunc(double ang)
        {
            ang = TransAngle(ang);
            lblResult.Text = lblResult.Text + "正切值为：" + Math.Tan(ang).ToString("f4");
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            lblResult.Text = "";
            this.Text = "将委托关联多个方法";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtAngle.Text == "")
            {
                lblResult.Text = "请输入角度值！";
                return;
            }
            TriFunc tri = new TriFunc(SinFunc);
            tri += CosFunc;
            tri += TanFunc;
            tri(double.Parse(txtAngle.Text.Trim()));

        }
    }
}
