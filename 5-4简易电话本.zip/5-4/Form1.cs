namespace _5_4
{
    using Microsoft.VisualBasic.ApplicationServices;
    using System.Collections;
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Text = "HashTableӦ��ʾ��";
        }
        public class User
        {
            static Hashtable Ht = new Hashtable();
            public string UserName;
            public string UserTel;
            public bool CheckUser()
            {
                return Ht.ContainsKey(UserName);
            }
            public void UserAdd()
            {
                Ht.Add(UserName, UserTel);
            }
            public void UserDel()
            {
                Ht.Remove(UserName);
            }
            public void UserEdit()
            {
                Ht.Remove(UserName);
                Ht.Add(UserName, UserTel);
            }
            public string UserQuery()
            {
                if (!Ht.ContainsKey(UserName))
                {
                    return "���޴��ˣ�";
                }
                else
                {
                    return Ht[UserName].ToString();
                }
            }
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            User u = new User();
            u.UserName = txtName.Text;
            u.UserTel = txtTel.Text;
            if (!u.CheckUser())
            {
                u.UserAdd();
                MessageBox.Show("��¼���ӳɹ���", "���", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("�û����Ѵ��ڣ�", "����", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnQuery_Click(object sender, EventArgs e)
        {
            User u = new User();
            u.UserName = txtName.Text;
            u.UserTel = txtTel.Text;
            txtTel.Text = u.UserQuery();
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            User u = new User();
            u.UserName = txtName.Text;
            if (u.CheckUser())
            {
                u.UserDel();
                MessageBox.Show("��¼ɾ���ɹ���", "���", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("�û��������ڣ�", "����", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            User u = new User();
            u.UserName = txtName.Text;
            if (u.CheckUser())
            {
                u.UserTel=txtTel.Text;
                u.UserEdit();
                MessageBox.Show("��¼�޸ĳɹ���","���",MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("�û������ڣ�", "����", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}