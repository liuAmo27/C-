namespace _6_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public class Args : EventArgs
        {
            private int _num;
            public int Number
            {
                set { _num = value; }
                get { return _num; }
            }
        }
        public delegate void IsEndDelegate(Args arg);
        public event IsEndDelegate IsEnd;
        protected void ActiveEvent(Args arg)
        {
            if (IsEnd != null)
            {
                IsEnd(arg);
            }
        }
        public void ShowMsg(Args arg)
        {
            lblInfo.Text = "ѭ��" + arg.Number.ToString() + "��ʱ�������˵�8�������7";
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            this.Text = "ʹ���¼�����ʾ��";
        }
        Random rd = new Random();

        private void btnBegin_Click(object sender, EventArgs e)
        {
            int i = 0;
            int j = 0;
            while (true)
            {
                i = i + 1;
                if (rd.Next(1, 10) == 7)
                {
                    j = j + 1;
                    if (j == 8)
                    {
                        Args arg = new Args();
                        arg.Number = i;
                        IsEnd += new IsEndDelegate(ShowMsg);
                        ActiveEvent(arg);
                        break;
                    }
                }
            }
        }
    }
}