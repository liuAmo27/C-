﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RoundLib
{
    public class Round
    {
        public float Account(float radius)
        {
            float c = (float)(2 * Math.PI * radius);
            return c;
        }
        public double Account(double radius)
        {
            double a = Math.PI * radius * radius;
            return a;
        }
        public double Account(double radius,double hight)
        {
            double v = Math.PI * radius * hight;
            return v;
        }
    }
}
