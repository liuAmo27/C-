namespace 圆计算
{
    using RoundLib;
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Text = "方法重载示例";
            lblResult.Text = "";
            txtH.Enabled = false;
            rbtnC.Select();
        }

        private void rbtnV_CheckedChanged(object sender, EventArgs e)
        {
            if (rbtnV.Checked)
            {
                txtH.Enabled = true;
            }
            else
            {
                txtH.Enabled = false;
            }
        }
        
        private void btnOK_Click(object sender, EventArgs e)
        {
            if(txtR.Text=="")
            {
                lblResult.Text = "必须输入半径!";
                return;
            }
            Round r = new Round();
            string msg = "";
            if(rbtnC.Checked)
            {
                float R = float.Parse(txtR.Text);
                msg = "圆周长为：" + r.Account(R).ToString("f");
            }
            if (rbtnA.Checked)
            {
                double R = double.Parse(txtR.Text);
                msg = "圆面积为：" + r.Account(R).ToString("f");
            }
            if (rbtnV.Checked)
            {
                double R = double.Parse(txtR.Text);
                double H = double.Parse(txtH.Text);
                msg = "圆柱体体积为：" + r.Account(R,H).ToString("f");
            }
            lblResult.Text = msg;
        }
    }
    
}