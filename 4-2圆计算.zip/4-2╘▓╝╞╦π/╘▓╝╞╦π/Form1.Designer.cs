﻿namespace 圆计算
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            txtR = new TextBox();
            txtH = new TextBox();
            rbtnC = new RadioButton();
            rbtnA = new RadioButton();
            rbtnV = new RadioButton();
            btnOK = new Button();
            lblResult = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(74, 112);
            label1.Name = "label1";
            label1.Size = new Size(69, 20);
            label1.TabIndex = 0;
            label1.Text = "输入半径";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(74, 198);
            label2.Name = "label2";
            label2.Size = new Size(69, 20);
            label2.TabIndex = 1;
            label2.Text = "圆柱体高";
            // 
            // txtR
            // 
            txtR.Location = new Point(173, 110);
            txtR.Name = "txtR";
            txtR.Size = new Size(125, 27);
            txtR.TabIndex = 2;
            // 
            // txtH
            // 
            txtH.Location = new Point(173, 198);
            txtH.Name = "txtH";
            txtH.Size = new Size(125, 27);
            txtH.TabIndex = 3;
            // 
            // rbtnC
            // 
            rbtnC.AutoSize = true;
            rbtnC.Location = new Point(403, 221);
            rbtnC.Name = "rbtnC";
            rbtnC.Size = new Size(60, 24);
            rbtnC.TabIndex = 4;
            rbtnC.TabStop = true;
            rbtnC.Text = "周长";
            rbtnC.UseVisualStyleBackColor = true;
            // 
            // rbtnA
            // 
            rbtnA.AutoSize = true;
            rbtnA.Location = new Point(495, 221);
            rbtnA.Name = "rbtnA";
            rbtnA.Size = new Size(60, 24);
            rbtnA.TabIndex = 5;
            rbtnA.TabStop = true;
            rbtnA.Text = "面积";
            rbtnA.UseVisualStyleBackColor = true;
            // 
            // rbtnV
            // 
            rbtnV.AutoSize = true;
            rbtnV.Location = new Point(600, 221);
            rbtnV.Name = "rbtnV";
            rbtnV.Size = new Size(60, 24);
            rbtnV.TabIndex = 6;
            rbtnV.TabStop = true;
            rbtnV.Text = "体积";
            rbtnV.UseVisualStyleBackColor = true;
            rbtnV.CheckedChanged += rbtnV_CheckedChanged;
            // 
            // btnOK
            // 
            btnOK.Location = new Point(449, 136);
            btnOK.Name = "btnOK";
            btnOK.Size = new Size(94, 29);
            btnOK.TabIndex = 7;
            btnOK.Text = "确定";
            btnOK.UseVisualStyleBackColor = true;
            btnOK.Click += btnOK_Click;
            // 
            // lblResult
            // 
            lblResult.AutoSize = true;
            lblResult.Location = new Point(74, 297);
            lblResult.Name = "lblResult";
            lblResult.Size = new Size(53, 20);
            lblResult.TabIndex = 8;
            lblResult.Text = "label3";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(9F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lblResult);
            Controls.Add(btnOK);
            Controls.Add(rbtnV);
            Controls.Add(rbtnA);
            Controls.Add(rbtnC);
            Controls.Add(txtH);
            Controls.Add(txtR);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox txtR;
        private TextBox txtH;
        private RadioButton rbtnC;
        private RadioButton rbtnA;
        private RadioButton rbtnV;
        private Button btnOK;
        private Label lblResult;
    }
}