﻿namespace Cuboid
{
    public class Cuboid
    {
        protected double length;
        private double width;
        private double high;
        public Cuboid(double x, double y,double z)
        {
            length = x; 
            width = y;
            high = z;
        }
        public virtual double Cubage()
        {
            return length * width * high;
        }
    }
    public class Cube : Cuboid
    {
        public Cube(double x):base(x,0,0) { }
        public override double Cubage() 
        {
            return length * length * length;
        }
    }
}