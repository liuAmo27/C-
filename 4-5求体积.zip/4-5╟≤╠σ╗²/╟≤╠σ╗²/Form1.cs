namespace 求体积
{
    using Cuboid;
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Text = "通过虚方法实现多态";
            label1.Text = "";
        }

        private void btnCuboid_Click(object sender, EventArgs e)
        {
            double Num1 = double.Parse(textBox1.Text);
            double Num2 = double.Parse(textBox2.Text);
            double Num3 = double.Parse(textBox3.Text);
            Cuboid c1 = new Cuboid(Num1, Num2, Num3);
            label1.Text = "长方体体积为：" + c1.Cubage().ToString();
        }

        private void btnCube_Click(object sender, EventArgs e)
        {
            double Num1=double.Parse(textBox1.Text);
            Cube c2 = new Cube(Num1);
            label1.Text="正方体体积为："+c2.Cubage().ToString();
        }
    }
}