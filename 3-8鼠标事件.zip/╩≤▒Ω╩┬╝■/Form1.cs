﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 鼠标事件
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Text = "鼠标事件应用示例";
            label1.Text = "当前鼠标的位置为：";
            button1.Text = "";
            button1.Image = Image.FromFile("face03.ico");
        }
        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            label1.Text = "当前鼠标位置为；" + "" + e.X + "，" + e.Y;
        }
        private void button1_MouseLeave(object sender, EventArgs e)
        {
            button1.Image = Image.FromFile("face03.ico");
        }

        private void button1_MouseEnter(object sender, EventArgs e)
        {
            button1.Image = Image.FromFile("face04.ico");
        }
    }
}
