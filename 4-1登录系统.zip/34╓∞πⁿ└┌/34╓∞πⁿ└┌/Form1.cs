﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _34朱泓磊
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }




        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (txtName.Text == "" || txtPwd.Text == "")
            {
                MessageBox.Show("用户名和密码不能为空", "出错", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            Users user = new Users();
            user.Name = txtName.Text;
            user.Pwd = txtPwd.Text;
            switch (user.IsPass())
            {
                case 0:
                    MessageBox.Show("你是合法用户，级别：管理员", "身份验证", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    break;
                case 1:
                    MessageBox.Show("你是合法用户，级别：管理员", "身份验证", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    break;
                case -1:
                    MessageBox.Show("你是合法用户，级别：管理员", "身份验证", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    break;
            }
        }
        class Users
        {
            private string _name, _pwd;
            public string Name
            {
                get { return _name; }
                set { _name = value; }
            }
            public string Pwd
            {
                get { return _pwd; }
                set { _pwd = value; }
            }
            public int IsPass()
            {
                int level = -1;
                if (this.Name == "zhangsan" && this.Pwd == "123456")
                {
                    level = 0;
                }
                if (this.Name == "lisi" && this.Pwd == "654321")
                {
                    level = 1;
                }
                return level;
            }
        }
    }
}
