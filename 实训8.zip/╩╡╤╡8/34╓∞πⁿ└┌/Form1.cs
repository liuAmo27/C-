﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace _34朱泓磊
{
    
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        class Expert
        {
            private string _name, _unit, _tel;
            public string Name
            {
                get { return _name; }
                set { _name = value; }
            }
            public string Unit
            {
                get { return _unit; }
                set { _unit = value; }
            }
            public string tel
            {
                get { return _tel; }
                set { _tel = value; }
            }
        }
        void FillType()
        {
            cboType.Items.Clear();
            cboNewType.Items.Clear();
            StreamReader sr = new StreamReader("type.txt", Encoding.Default);
            try
            {
                while (!sr.EndOfStream)
                {
                    string Item = sr.ReadLine();
                    if (Item != "")
                    {
                        cboType.Items.Add(Item);
                        cboNewType.Items.Add(Item);
                    }
                }
                cboType.Text = cboType.Items[0].ToString();
                cboNewType.Text = cboNewType.Items[0].ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "出错", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            finally
            {
                sr.Close();
            }
        }
        List<Expert> ExpertInfo = new List<Expert>();
        void GetData()
        {
            ExpertInfo.Clear();
            if (!File.Exists(cboType.Text + ".txt"))
            {
                MessageBox.Show("尚未建立该类型的专家库!", "出错", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            StreamReader sr = new StreamReader(cboType.Text + ".txt", Encoding.Default);
            try
            {
                while (!sr.EndOfStream)
                {
                    Expert exp = new Expert();
                    exp.Name = sr.ReadLine();
                    if(exp.Name != "")
                    {
                        exp.Unit = sr.ReadLine();
                        exp.tel = sr.ReadLine();
                    }
                    ExpertInfo.Add(exp);
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "出错", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            finally
            {
                sr.Close();
            }
        }
        void FillData()
        {
            if(dgvList.ColumnCount == 0)
            {
                DataGridViewTextBoxColumn col1 = new DataGridViewTextBoxColumn();
                col1.Width = 100;
                col1.HeaderText = "姓名";
                col1.DataPropertyName = "Name";
                DataGridViewTextBoxColumn col2 = new DataGridViewTextBoxColumn();
                col2.Width = 187;
                col2.HeaderText = "工作单位";
                col2.DataPropertyName = "Unit";
                DataGridViewTextBoxColumn col3 = new DataGridViewTextBoxColumn();
                col3.Width = 100;
                col3.HeaderText = "联系电话";
                col3.DataPropertyName = "Tel";
                dgvList.Columns.Add(col1);
                dgvList.Columns.Add(col2);
                dgvList.Columns.Add(col3);
            }
            dgvList.DataSource = ExpertInfo;
        }



        private void Form1_Load(object sender, EventArgs e)
        {
            this.Text = "专家库管理程序";
            FillType();
            GetData();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            dgvList.DataSource = null;
            Random rd = new Random();
            GetData();
            int Num;
            try
            {
                Num = int.Parse(txtNum.Text);
            }
            catch (FormatException)
            {
                MessageBox.Show("输入的数据格式有误!", "出错", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (Num > ExpertInfo.Count)
            {
                MessageBox.Show("目前该项目专家库中仅有" + ExpertInfo.Count.ToString() + "位专家!", "出错", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            int RemoveRows = ExpertInfo.Count - int.Parse(txtNum.Text);
            for(int i = 0; i < RemoveRows; i++)
            {
                ExpertInfo.RemoveAt(rd.Next(0, ExpertInfo.Count));

            }
            FillData();
        }

        private void cboType_SelectedIndexChanged(object sender, EventArgs e)
        {
            dgvList.DataSource = null;
            TabControl combo = (TabControl)sender;
            if(combo.Name != "cboNewType")
            {
                GetData();

            }
            FillData();
        }

        private void btnAll_Click(object sender, EventArgs e)
        {
            dgvList.DataSource = null;
            GetData();
            FillData();

        }

        private void btnType_Click(object sender, EventArgs e)
        {
            if(txtType.Text == "")
            {
                MessageBox.Show("项目类型名称不能为空!", "出错", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            for(int i = 0; i < cboNewType.Items.Count; i++)
            {
                if (cboNewType.Items[i].ToString() == txtType.Text)
                {
                    MessageBox.Show("要添加的项目类型已存在!", "出错", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }
            StreamWriter sw = new StreamWriter("type.txt", true, Encoding.Default);
            try
            {
                sw.WriteLine(txtType.Text);

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "出错", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            finally
            {
                sw.Close();

            }
            MessageBox.Show("数据添加成功!", "完成", MessageBoxButtons.OK, MessageBoxIcon.Information);
            txtType.Text = "";
            txtType.Focus();
            FillType();
        }

        private void btnExpert_Click(object sender, EventArgs e)
        {
            if(txtName.Text ==""||txtUnit.Text ==""||txtTel.Text == "")
            {
                MessageBox.Show("请输入完整数据!", "出错", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (File.Exists(cboNewType.Text + ".txt"))
            {
                StreamReader sr = new StreamReader(cboNewType.Text + ".txt", Encoding.Default);
                try
                {
                    while (!sr.EndOfStream)
                    {
                        string ExpName = sr.ReadLine();
                        string ExpUnit = sr.ReadLine();
                        string ExpTel = sr.ReadLine();
                        if(ExpName ==txtName.Text && ExpUnit == txtUnit.Text && ExpTel == txtTel.Text)
                        {
                            MessageBox.Show("要添加的专家记录已存在!", "出错", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                    }
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message, "出错", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                finally
                {
                    sr.Close();
                }
            }
            StreamWriter sw = new StreamWriter(cboNewType.Text + ".txt", true, Encoding.Default);
            try
            {
                sw.WriteLine(txtName.Text);
                sw.WriteLine(txtUnit.Text);
                sw.WriteLine(txtTel.Text);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "出错", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            finally
            {
                sw.Close();

            }
            MessageBox.Show("数据添加成功!", "完成", MessageBoxButtons.OK, MessageBoxIcon.Information);
            txtName.Text = "";
            txtUnit.Text = "";
            txtTel.Text = "";
            txtName.Focus();
        }

        private void cboNewType_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
   
    
}
