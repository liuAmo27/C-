﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyClassLib
{
    public class Arithmetic
    {
        private static string _opt1;
        private static string _opt2;
        public static string OperandA
        {
            get { return _opt1; }
            set { _opt1 = value; }
        }
        public static string OperandB
        {
            get { return _opt2; }
            set { _opt2 = value; }
        }
        public double ToDouble(string num)
        {
            return double.Parse(num);
        }
    }
    public class NumAdd : Arithmetic
    {
        public string GetResult()
        {
            double a = ToDouble(OperandA);
            double b = ToDouble(OperandB);
            double sum = a + b;
            return sum.ToString();
        }
    }
    public class NumSub : Arithmetic
    {
        public string GetResult()
        {
            double a = ToDouble(OperandA);
            double b = ToDouble(OperandB);
            double sum = a - b;
            return sum.ToString();
        }
    }
    public class NumMulit : Arithmetic
    {
        public string GetResult()
        {
            double a = ToDouble(OperandA);
            double b = ToDouble(OperandB);
            double sum = a * b;
            return sum.ToString();
        }
    }
    public class NumDivi : Arithmetic
    {
        public string GetResult()
        {
            double a = ToDouble(OperandA);
            double b = ToDouble(OperandB);
            double sum = a / b;
            return sum.ToString();
        }
    }
}
