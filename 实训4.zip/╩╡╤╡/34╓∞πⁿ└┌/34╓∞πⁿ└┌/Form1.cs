﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _34朱泓磊
{
    using MyClassLib;
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Text = "四则运算";
            lblResult.Text = "";
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if (txtA.Text == "" || txtB.Text == "")
            {
                lblResult.Text = "两个操作数不能为空！";
                return;
            }
            Arithmetic.OperandA = txtA.Text;
            Arithmetic.OperandB = txtB.Text;
            NumAdd add = new NumAdd();
            NumSub sub = new NumSub();
            NumMulit mulit = new NumMulit();
            NumDivi divi = new NumDivi();
            if (rbtnAdd.Checked)
            {
                lblResult.Text = "两数相加的结果为："+add.GetResult();
            }
            if (rbtnSub.Checked)
            {
                lblResult.Text = "两数相减的结果为：" + sub.GetResult();
            }
            if (rbtnMulit.Checked)
            {
                lblResult.Text = "两数相乘的结果为：" + mulit.GetResult();
            }
            if (rbtnDivi.Checked)
            {
                lblResult.Text = "两数相除的结果为：" + divi.GetResult();
            }
        }
    }
}
