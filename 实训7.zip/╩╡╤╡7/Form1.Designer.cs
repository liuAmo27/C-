﻿namespace 实训7
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            grpAdd = new GroupBox();
            btnBack = new Button();
            btnOK = new Button();
            txtUnit = new TextBox();
            txtTel = new TextBox();
            txtName = new TextBox();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            btnQuery = new Button();
            btnShowAll = new Button();
            btnDel = new Button();
            btnAdd = new Button();
            txtKey = new TextBox();
            rbtnName = new RadioButton();
            rbtnTel = new RadioButton();
            rbtnUnit = new RadioButton();
            dgvList = new DataGridView();
            grpAdd.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvList).BeginInit();
            SuspendLayout();
            // 
            // grpAdd
            // 
            grpAdd.Controls.Add(btnBack);
            grpAdd.Controls.Add(btnOK);
            grpAdd.Controls.Add(txtUnit);
            grpAdd.Controls.Add(txtTel);
            grpAdd.Controls.Add(txtName);
            grpAdd.Controls.Add(label3);
            grpAdd.Controls.Add(label2);
            grpAdd.Controls.Add(label1);
            grpAdd.Location = new Point(168, 12);
            grpAdd.Name = "grpAdd";
            grpAdd.Size = new Size(431, 161);
            grpAdd.TabIndex = 0;
            grpAdd.TabStop = false;
            grpAdd.Text = "添加新记录";
            // 
            // btnBack
            // 
            btnBack.Location = new Point(298, 91);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(75, 47);
            btnBack.TabIndex = 7;
            btnBack.Text = "返回";
            btnBack.UseVisualStyleBackColor = true;
            btnBack.Click += btnBack_Click;
            // 
            // btnOK
            // 
            btnOK.Location = new Point(298, 32);
            btnOK.Name = "btnOK";
            btnOK.Size = new Size(75, 47);
            btnOK.TabIndex = 6;
            btnOK.Text = "确定";
            btnOK.UseVisualStyleBackColor = true;
            btnOK.Click += btnOK_Click;
            // 
            // txtUnit
            // 
            txtUnit.Location = new Point(140, 118);
            txtUnit.Name = "txtUnit";
            txtUnit.Size = new Size(100, 23);
            txtUnit.TabIndex = 5;
            // 
            // txtTel
            // 
            txtTel.Location = new Point(140, 78);
            txtTel.Name = "txtTel";
            txtTel.Size = new Size(100, 23);
            txtTel.TabIndex = 4;
            // 
            // txtName
            // 
            txtName.Location = new Point(140, 32);
            txtName.Name = "txtName";
            txtName.Size = new Size(100, 23);
            txtName.TabIndex = 3;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(70, 118);
            label3.Name = "label3";
            label3.Size = new Size(32, 17);
            label3.TabIndex = 2;
            label3.Text = "单位";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(70, 81);
            label2.Name = "label2";
            label2.Size = new Size(32, 17);
            label2.TabIndex = 1;
            label2.Text = "电话";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(69, 38);
            label1.Name = "label1";
            label1.Size = new Size(32, 17);
            label1.TabIndex = 0;
            label1.Text = "姓名";
            // 
            // btnQuery
            // 
            btnQuery.Location = new Point(193, 235);
            btnQuery.Name = "btnQuery";
            btnQuery.Size = new Size(75, 47);
            btnQuery.TabIndex = 1;
            btnQuery.Text = "查询";
            btnQuery.UseVisualStyleBackColor = true;
            btnQuery.Click += btnQuery_Click;
            // 
            // btnShowAll
            // 
            btnShowAll.Location = new Point(287, 235);
            btnShowAll.Name = "btnShowAll";
            btnShowAll.Size = new Size(75, 47);
            btnShowAll.TabIndex = 2;
            btnShowAll.Text = "显示全部";
            btnShowAll.UseVisualStyleBackColor = true;
            btnShowAll.Click += btnShowAll_Click;
            // 
            // btnDel
            // 
            btnDel.Location = new Point(384, 235);
            btnDel.Name = "btnDel";
            btnDel.Size = new Size(75, 47);
            btnDel.TabIndex = 3;
            btnDel.Text = "删除";
            btnDel.UseVisualStyleBackColor = true;
            btnDel.Click += btnDel_Click;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(475, 235);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(75, 47);
            btnAdd.TabIndex = 4;
            btnAdd.Text = "添加";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // txtKey
            // 
            txtKey.Location = new Point(196, 198);
            txtKey.Name = "txtKey";
            txtKey.Size = new Size(128, 23);
            txtKey.TabIndex = 5;
            // 
            // rbtnName
            // 
            rbtnName.AutoSize = true;
            rbtnName.Checked = true;
            rbtnName.Location = new Point(353, 199);
            rbtnName.Name = "rbtnName";
            rbtnName.Size = new Size(50, 21);
            rbtnName.TabIndex = 6;
            rbtnName.TabStop = true;
            rbtnName.Text = "姓名";
            rbtnName.TextAlign = ContentAlignment.TopLeft;
            rbtnName.UseVisualStyleBackColor = true;
            // 
            // rbtnTel
            // 
            rbtnTel.AutoSize = true;
            rbtnTel.Location = new Point(422, 199);
            rbtnTel.Name = "rbtnTel";
            rbtnTel.Size = new Size(50, 21);
            rbtnTel.TabIndex = 7;
            rbtnTel.Text = "电话";
            rbtnTel.UseVisualStyleBackColor = true;
            // 
            // rbtnUnit
            // 
            rbtnUnit.AutoSize = true;
            rbtnUnit.Location = new Point(491, 199);
            rbtnUnit.Name = "rbtnUnit";
            rbtnUnit.Size = new Size(50, 21);
            rbtnUnit.TabIndex = 8;
            rbtnUnit.Text = "单位";
            rbtnUnit.UseVisualStyleBackColor = true;
            // 
            // dgvList
            // 
            dgvList.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvList.Location = new Point(168, 288);
            dgvList.Name = "dgvList";
            dgvList.RowTemplate.Height = 25;
            dgvList.Size = new Size(431, 150);
            dgvList.TabIndex = 9;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(dgvList);
            Controls.Add(rbtnUnit);
            Controls.Add(rbtnTel);
            Controls.Add(rbtnName);
            Controls.Add(txtKey);
            Controls.Add(btnAdd);
            Controls.Add(btnDel);
            Controls.Add(btnShowAll);
            Controls.Add(btnQuery);
            Controls.Add(grpAdd);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            grpAdd.ResumeLayout(false);
            grpAdd.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvList).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox grpAdd;
        private Button btnBack;
        private Button btnOK;
        private TextBox txtUnit;
        private TextBox txtTel;
        private TextBox txtName;
        private Label label3;
        private Label label2;
        private Label label1;
        private Button btnQuery;
        private Button btnShowAll;
        private Button btnDel;
        private Button btnAdd;
        private TextBox txtKey;
        private RadioButton rbtnName;
        private RadioButton rbtnTel;
        private RadioButton rbtnUnit;
        private DataGridView dgvList;
    }
}