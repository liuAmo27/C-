namespace 实训7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        class PhoneBook
        {
            private string _name, _tel, _unit;
            public string UserName
            {
                get { return _name; }
                set { _name = value; }
            }
            public string UserTel
            {
                get { return _tel; }
                set { _tel = value; }
            }
            public string UserUnit
            {
                get { return _unit; }
                set { _unit = value; }
            }
            public PhoneBook(string _name, string _tel, string _unit)
            {
                UserName = _name;
                UserTel = _tel;
                UserUnit = _unit;
            }
        }
        List<PhoneBook> UserRecord = new List<PhoneBook>();
        private void Form1_Load(object sender, EventArgs e)
        {
            grpAdd.Visible = false;
            dgvList.Top = 6;
            dgvList.Left = 6;
            this.Height = 270;
            this.Text = "List<T>应用示例";
            PhoneBook zhang = new PhoneBook("张三", "1234567", "人事处");
            PhoneBook li = new PhoneBook("李四", "2345678", "教务处");
            PhoneBook wang = new PhoneBook("王五", "3456789", "财务处");
            PhoneBook zhao = new PhoneBook("赵六", "4657980", "教务处");
            UserRecord.Add(zhang);
            UserRecord.Add(li);
            UserRecord.Add(wang);
            UserRecord.Add(zhao);
            DataGridViewTextBoxColumn col1 = new DataGridViewTextBoxColumn();
            col1.HeaderText = "姓名";
            col1.DataPropertyName = "UserName";
            col1.Name = "Name";
            DataGridViewTextBoxColumn col2 = new DataGridViewTextBoxColumn();
            col2.HeaderText = "电话";
            col2.DataPropertyName = "UserTel";
            col2.Name = "Tel";
            DataGridViewTextBoxColumn col3 = new DataGridViewTextBoxColumn();
            col3.HeaderText = "单位";
            col3.DataPropertyName = "UserUnit";
            col3.Name = "Unit";
            dgvList.Columns.Add(col1);
            dgvList.Columns.Add(col2);
            dgvList.Columns.Add(col3);
            dgvList.DataSource = UserRecord;
        }
        static string userkey = "";
        static int userkeytype = 1;
        private static bool IsInclud(PhoneBook user)
        {
            bool b = false;
            switch (userkeytype)
            {
                case 1:
                    if (user.UserName.IndexOf(userkey, 0) != -1)
                    {
                        b = true;
                    }
                    break;
                case 2:
                    if (user.UserTel.IndexOf(userkey, 0) != -1)
                    {
                        b = true;
                    }
                    break;
                case 3:
                    if (user.UserUnit.IndexOf(userkey, 0) != -1)
                    {
                        b = true;
                    }
                    break;
            }
            return b;
        }

        private void btnQuery_Click(object sender, EventArgs e)
        {
            if (txtKey.Text == "")
            {
                MessageBox.Show("请输入查询关键字！", "注意！",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            userkey = txtKey.Text;
            if (rbtnName.Checked)
            {
                userkeytype = 1;
            }
            if (rbtnTel.Checked)
            {
                userkeytype = 2;
            }
            if (rbtnUnit.Checked)
            {
                userkeytype = 3;
            }
            List<PhoneBook> sublist = UserRecord.FindAll(IsInclud);
            if (sublist.Count == 0)
            {
                MessageBox.Show("未找到符合条件的记录！", "注意！",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                dgvList.DataSource = sublist;
            }
        }

        private void btnShowAll_Click(object sender, EventArgs e)
        {
            dgvList.DataSource = UserRecord;
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            int n = dgvList.CurrentCell.RowIndex;
            UserRecord.RemoveAt(n);
            dgvList.DataSource = new List<PhoneBook>();
            dgvList.DataSource = UserRecord;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            dgvList.Visible = false;
            grpAdd.Visible = true;
            txtName.Focus();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if (txtName.Text == "" || txtTel.Text == "" || txtUnit.Text == "")
            {
                MessageBox.Show("请输入所有数据！", "注意！",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            UserRecord.Add(new PhoneBook(txtName.Text,txtTel.Text,txtUnit.Text));
            txtName.Text = "";
            txtTel.Text = "";
            txtUnit.Text = "";
            txtName.Focus();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            dgvList.DataSource=new List<PhoneBook>();
            dgvList.DataSource = UserRecord;
            grpAdd.Visible = false;
            dgvList.Visible=true;
        }
    }
}