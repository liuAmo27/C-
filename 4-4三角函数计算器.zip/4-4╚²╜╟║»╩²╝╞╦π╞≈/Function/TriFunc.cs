﻿namespace Function
{
    public class TriFunc
    {
        private double _angle;
        public double Angle
        {
            get { return _angle; }
            set { _angle = value; }
        }
        protected double TransAngle(double a)
        {
            a = a * Math.PI / 180;
            return a;
        }
    }
    public class SinFunc: TriFunc
    {
        public double GetVal()
        {
            Angle=TransAngle(Angle);
            return Math.Sin(Angle);
        }
    }
    public class CosFunc : TriFunc
    {
        public double GetVal()
        {
            Angle = TransAngle(Angle);
            return Math.Cos(Angle);
        }
    }
    public class TanFunc : TriFunc
    {
        public double GetVal()
        {
            Angle = TransAngle(Angle);
            return Math.Tan(Angle);
        }
    }
}