namespace 三角函数计算器
{
    using Function;
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Text = "三角函数计算器";
            rbtnSin.Checked = true;
            lblResult.Text = "";
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if(rbtnSin.Checked)
            {
                SinFunc sin = new SinFunc();
                sin.Angle = double.Parse(txtAngle.Text.Trim());
                lblResult.Text = "sin" + txtAngle.Text + "°=" + sin.GetVal().ToString("f4");
            }
            if (rbtnCos.Checked)
            {
                CosFunc cos = new CosFunc();
                cos.Angle = double.Parse(txtAngle.Text.Trim());
                lblResult.Text = "cos" + txtAngle.Text + "°=" + cos.GetVal().ToString("f4");
            }
            if (rbtnTan.Checked)
            {
                TanFunc tan = new TanFunc();
                tan.Angle = double.Parse(txtAngle.Text.Trim());
                lblResult.Text = "tan" + txtAngle.Text + "°=" + tan.GetVal().ToString("f4");
            }
            if (rbtnCot.Checked)
            {
                TanFunc tan = new TanFunc();
                tan.Angle = double.Parse(txtAngle.Text.Trim());
                lblResult.Text = "cot" + txtAngle.Text + "°=" + (1/tan.GetVal()).ToString("f4");
            }
        }
    }
}