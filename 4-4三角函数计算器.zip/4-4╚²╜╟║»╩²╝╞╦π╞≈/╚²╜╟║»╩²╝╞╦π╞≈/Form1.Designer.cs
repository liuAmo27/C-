﻿namespace 三角函数计算器
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            lblResult = new Label();
            btnOK = new Button();
            txtAngle = new TextBox();
            rbtnSin = new RadioButton();
            rbtnCos = new RadioButton();
            rbtnTan = new RadioButton();
            rbtnCot = new RadioButton();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(100, 114);
            label1.Name = "label1";
            label1.Size = new Size(144, 20);
            label1.TabIndex = 0;
            label1.Text = "请输入一个角度值：";
            // 
            // lblResult
            // 
            lblResult.AutoSize = true;
            lblResult.Location = new Point(191, 244);
            lblResult.Name = "lblResult";
            lblResult.Size = new Size(53, 20);
            lblResult.TabIndex = 1;
            lblResult.Text = "label2";
            // 
            // btnOK
            // 
            btnOK.Location = new Point(451, 110);
            btnOK.Name = "btnOK";
            btnOK.Size = new Size(94, 29);
            btnOK.TabIndex = 2;
            btnOK.Text = "确定";
            btnOK.UseVisualStyleBackColor = true;
            btnOK.Click += btnOK_Click;
            // 
            // txtAngle
            // 
            txtAngle.Location = new Point(260, 107);
            txtAngle.Name = "txtAngle";
            txtAngle.Size = new Size(125, 27);
            txtAngle.TabIndex = 3;
            // 
            // rbtnSin
            // 
            rbtnSin.AutoSize = true;
            rbtnSin.Checked = true;
            rbtnSin.Location = new Point(121, 172);
            rbtnSin.Name = "rbtnSin";
            rbtnSin.Size = new Size(50, 24);
            rbtnSin.TabIndex = 4;
            rbtnSin.TabStop = true;
            rbtnSin.Text = "sin";
            rbtnSin.UseVisualStyleBackColor = true;
            // 
            // rbtnCos
            // 
            rbtnCos.AutoSize = true;
            rbtnCos.Location = new Point(222, 172);
            rbtnCos.Name = "rbtnCos";
            rbtnCos.Size = new Size(55, 24);
            rbtnCos.TabIndex = 5;
            rbtnCos.Text = "cos";
            rbtnCos.UseVisualStyleBackColor = true;
            // 
            // rbtnTan
            // 
            rbtnTan.AutoSize = true;
            rbtnTan.Location = new Point(320, 172);
            rbtnTan.Name = "rbtnTan";
            rbtnTan.Size = new Size(53, 24);
            rbtnTan.TabIndex = 6;
            rbtnTan.Text = "tan";
            rbtnTan.UseVisualStyleBackColor = true;
            // 
            // rbtnCot
            // 
            rbtnCot.AutoSize = true;
            rbtnCot.Location = new Point(403, 172);
            rbtnCot.Name = "rbtnCot";
            rbtnCot.Size = new Size(54, 24);
            rbtnCot.TabIndex = 7;
            rbtnCot.Text = "cot";
            rbtnCot.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(9F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(rbtnCot);
            Controls.Add(rbtnTan);
            Controls.Add(rbtnCos);
            Controls.Add(rbtnSin);
            Controls.Add(txtAngle);
            Controls.Add(btnOK);
            Controls.Add(lblResult);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label lblResult;
        private Button btnOK;
        private TextBox txtAngle;
        private RadioButton rbtnSin;
        private RadioButton rbtnCos;
        private RadioButton rbtnTan;
        private RadioButton rbtnCot;
    }
}