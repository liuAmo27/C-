﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            btnCancel = new Button();
            btnOK = new Button();
            txtTel = new TextBox();
            txtClass = new TextBox();
            txtName = new TextBox();
            txtNo = new TextBox();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            dgvStuInfo = new DataGridView();
            btnAdd = new Button();
            btnEdit = new Button();
            btnDel = new Button();
            btnQuery = new Button();
            txtKey = new TextBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvStuInfo).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(btnCancel);
            panel1.Controls.Add(btnOK);
            panel1.Controls.Add(txtTel);
            panel1.Controls.Add(txtClass);
            panel1.Controls.Add(txtName);
            panel1.Controls.Add(txtNo);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Location = new Point(178, 318);
            panel1.Name = "panel1";
            panel1.Size = new Size(445, 100);
            panel1.TabIndex = 13;
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(361, 54);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(75, 23);
            btnCancel.TabIndex = 9;
            btnCancel.Text = "取消";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // btnOK
            // 
            btnOK.Location = new Point(361, 12);
            btnOK.Name = "btnOK";
            btnOK.Size = new Size(75, 23);
            btnOK.TabIndex = 8;
            btnOK.Text = "确定";
            btnOK.UseVisualStyleBackColor = true;
            btnOK.Click += btnOK_Click;
            // 
            // txtTel
            // 
            txtTel.Location = new Point(247, 57);
            txtTel.Name = "txtTel";
            txtTel.Size = new Size(100, 23);
            txtTel.TabIndex = 7;
            // 
            // txtClass
            // 
            txtClass.Location = new Point(66, 57);
            txtClass.Name = "txtClass";
            txtClass.Size = new Size(100, 23);
            txtClass.TabIndex = 6;
            // 
            // txtName
            // 
            txtName.Location = new Point(247, 9);
            txtName.Name = "txtName";
            txtName.Size = new Size(100, 23);
            txtName.TabIndex = 5;
            // 
            // txtNo
            // 
            txtNo.Location = new Point(66, 15);
            txtNo.Name = "txtNo";
            txtNo.Size = new Size(100, 23);
            txtNo.TabIndex = 4;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(181, 57);
            label4.Name = "label4";
            label4.Size = new Size(32, 17);
            label4.TabIndex = 3;
            label4.Text = "电话";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(5, 57);
            label3.Name = "label3";
            label3.Size = new Size(32, 17);
            label3.TabIndex = 2;
            label3.Text = "班级";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(181, 15);
            label2.Name = "label2";
            label2.Size = new Size(32, 17);
            label2.TabIndex = 1;
            label2.Text = "姓名";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(5, 15);
            label1.Name = "label1";
            label1.Size = new Size(32, 17);
            label1.TabIndex = 0;
            label1.Text = "学号";
            // 
            // dgvStuInfo
            // 
            dgvStuInfo.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvStuInfo.Location = new Point(178, 95);
            dgvStuInfo.Name = "dgvStuInfo";
            dgvStuInfo.RowTemplate.Height = 25;
            dgvStuInfo.Size = new Size(445, 205);
            dgvStuInfo.TabIndex = 12;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(539, 33);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(75, 42);
            btnAdd.TabIndex = 11;
            btnAdd.Text = "添加";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnEdit
            // 
            btnEdit.Location = new Point(458, 33);
            btnEdit.Name = "btnEdit";
            btnEdit.Size = new Size(75, 42);
            btnEdit.TabIndex = 10;
            btnEdit.Text = "修改";
            btnEdit.UseVisualStyleBackColor = true;
            btnEdit.Click += btnEdit_Click;
            // 
            // btnDel
            // 
            btnDel.Location = new Point(377, 33);
            btnDel.Name = "btnDel";
            btnDel.RightToLeft = RightToLeft.No;
            btnDel.Size = new Size(75, 42);
            btnDel.TabIndex = 9;
            btnDel.Text = "删除";
            btnDel.UseVisualStyleBackColor = true;
            btnDel.Click += btnDel_Click;
            // 
            // btnQuery
            // 
            btnQuery.Location = new Point(296, 33);
            btnQuery.Name = "btnQuery";
            btnQuery.Size = new Size(75, 42);
            btnQuery.TabIndex = 8;
            btnQuery.Text = "查询";
            btnQuery.UseVisualStyleBackColor = true;
            btnQuery.Click += btnQuery_Click;
            // 
            // txtKey
            // 
            txtKey.Location = new Point(178, 43);
            txtKey.Name = "txtKey";
            txtKey.Size = new Size(106, 23);
            txtKey.TabIndex = 7;
            txtKey.LostFocus += new EventHandler(txtKey_LostFocus);
            txtKey.GotFocus += new EventHandler(txtKey_GotFocus);
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(panel1);
            Controls.Add(dgvStuInfo);
            Controls.Add(btnAdd);
            Controls.Add(btnEdit);
            Controls.Add(btnDel);
            Controls.Add(btnQuery);
            Controls.Add(txtKey);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvStuInfo).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        private void TxtKey_LostFocus(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void TxtKey_GotFocus(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion

        private Panel panel1;
        private Button btnCancel;
        private Button btnOK;
        private TextBox txtTel;
        private TextBox txtClass;
        private TextBox txtName;
        private TextBox txtNo;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private DataGridView dgvStuInfo;
        private Button btnAdd;
        private Button btnEdit;
        private Button btnDel;
        private Button btnQuery;
        private TextBox txtKey;
    }
}