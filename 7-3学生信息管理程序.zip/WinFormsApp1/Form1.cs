using System.Formats.Asn1;
using System.Xml.Linq;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        class StuInfo
        {
            private string _no, _name, _class, _tel;
            public string StuNo
            {
                get { return _no; }
                set { _no = value; }
            }
            public string StuName
            {
                get { return _name; }
                set { _name = value; }
            }
            public string StuClass
            {
                get { return _class; }
                set { _class = value; }
            }
            public string StuTel
            {
                get { return _tel; }
                set { _tel = value; }

            }
            public StuInfo(string _no, string _name, string _class, string _tel)
            {
                StuNo = _no;
                StuName = _name;
                StuClass = _class;
                StuTel = _tel;
            }
        }
        Dictionary<string, StuInfo> StuDic = new Dictionary<string, StuInfo>();
        private void FillGird(Dictionary<string, StuInfo> Dic)
        {
            if (dgvStuInfo.ColumnCount == 0)
            {
                DataGridViewTextBoxColumn coll = new DataGridViewTextBoxColumn();
                coll.HeaderText = "ѧ��";
                coll.DataPropertyName = "StuNo";
                coll.Name = "No";
                DataGridViewTextBoxColumn col2 = new DataGridViewTextBoxColumn();
                col2.HeaderText = "����";
                col2.DataPropertyName = "StuName";
                col2.Name = "Name";
                DataGridViewTextBoxColumn col3 = new DataGridViewTextBoxColumn();
                col3.HeaderText = "�༶";
                col3.DataPropertyName = "StuClass";
                col3.Name = "Class";
                DataGridViewTextBoxColumn col4 = new DataGridViewTextBoxColumn();
                col4.HeaderText = "�绰";
                col4.DataPropertyName = "StuTel";
                col4.Name = "Tel";
                dgvStuInfo.Columns.Add(coll);
                dgvStuInfo.Columns.Add(col2);
                dgvStuInfo.Columns.Add(col3);
                dgvStuInfo.Columns.Add(col4);
            }
            BindingSource bs = new BindingSource();
            bs.DataSource = Dic.Values;
            dgvStuInfo.DataSource = bs;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            panel1.Visible = false;
            this.Height = 270;
            this.Text = "Dictionary<K,V>���ͼ���Ӧ��ʾ��";
            txtKey.Text = "������ѧ��";
            txtKey.ForeColor = Color.DarkGray;
            StuInfo zhang = new StuInfo("0001", "����", "����1001", "1234567");
            StuInfo wang = new StuInfo("0002", "����", "����1001", "2345678");
            StuInfo li = new StuInfo("0003", "����", "����1001", "3456789");
            StuInfo zhao = new StuInfo("0004", "����", "����1001", "4567890");
            StuDic.Add(zhang.StuNo, zhang);
            StuDic.Add(wang.StuNo, wang);
            StuDic.Add(li.StuNo, li);
            StuDic.Add(zhao.StuNo, zhao);
            FillGird(StuDic);
        }
        private void txtKey_GotFocus(object sender, EventArgs e)
        {
            if(txtKey.Text == "������ѧ��")
            {
                txtKey.ForeColor = Color.Black;
                txtKey.Text = "";
            }
        }
        private void txtKey_LostFocus(object sender, EventArgs e)
        {
            if(txtKey.Text == "")
            {
                txtKey.Text = "������ѧ��";
                txtKey.ForeColor = Color.DarkGray;
            }
        }
        private void btnQuery_Click(object sender, EventArgs e)
        {
            if(txtKey.Text == "" || txtKey.Text == "������ѧ��")
            {
                FillGird(StuDic) ;
                return;
            }
            if (!StuDic.ContainsKey(txtKey.Text))
            {
                MessageBox.Show("���޴��ˣ�","������",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                StuInfo stu = StuDic[txtKey.Text];
                Dictionary<string,StuInfo>subdic =
                    new Dictionary<string,StuInfo>();
                subdic.Add(stu.StuNo, stu);
                FillGird(subdic);
            }
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            if (!StuDic.ContainsKey(txtKey.Text))
            {
                MessageBox.Show("Ҫɾ���ļ�¼�����ڣ�", "������",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                StuDic.Remove(txtKey.Text);
                FillGird(StuDic);
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (!StuDic.ContainsKey(txtKey.Text))
            {
                MessageBox.Show("Ҫ�޸ĵļ�¼�����ڣ�", "������",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                this.Height = 385;
                panel1.Visible = true;
                StuInfo stu = StuDic[txtKey.Text];
                txtNo.Enabled = false;
                txtNo.Text=stu.StuNo;
                txtName.Text = stu.StuName;
                txtClass.Text = stu.StuClass;
                txtTel.Text = stu.StuTel;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            this.Height = 385;
            panel1.Visible = true;
            txtNo.Focus();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if(txtNo.Enabled)
            {
                if (StuDic.ContainsKey(txtKey.Text) )
                {
                    MessageBox.Show("ѧ���Ѵ��ڣ����������룡", "������",
                   MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                if (txtNo.Text == "" || txtName.Text == "" ||
                txtClass.Text == "" || txtTel.Text == "")
                {
                    MessageBox.Show("����д�������ݣ�", "����",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                StuInfo stu = new StuInfo(txtNo.Text, txtName.Text, txtClass.Text, txtTel.Text);
                StuDic.Add(txtNo.Text, stu);
                FillGird(StuDic);
            }
            else
            {
                StuDic.Remove(txtKey.Text);
                StuInfo stu =new StuInfo(txtNo.Text, txtName.Text, txtClass.Text, txtTel.Text);
                StuDic.Add(txtNo.Text, stu);
                FillGird(StuDic);
                txtNo.Enabled = true;
            }
            btnCancel_Click(null, null); 
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            txtNo.Text = "";
            txtName.Text = "";
            txtClass.Text = "";
            txtTel.Text = "";
            panel1.Visible=false;
            this.Height = 270;
            txtKey.Text = "������ѧ��";
            txtKey.ForeColor = Color.DarkGray;
        }
    }
}//txtNo.txt, txtName.txt, txtClass.txt, txtTel.Text