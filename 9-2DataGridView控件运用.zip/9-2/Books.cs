﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _9_2
{
    internal class Books
    {
        string _id, _name, _author;
        double _price;
        DateTime _date;
        public string ID
        {
            get { return _id; }
            set { _id = value; }
        }
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        public string Author
        {
            get { return _author; }
            set { _author = value; }
        }
        public double Price
        {
            get { return _price; }
            set { _price = value; }
        }
        public DateTime Date
        {
            get { return _date; }
            set { _date = value; }
        }
        public Books(string _id, string _name)
        {
            ID = _id;
            Name = _name;
        }

    }
}
