using static System.Reflection.Metadata.BlobBuilder;

namespace _9_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Random rd = new Random();
        Books CreateBooks()
        {
            int seed;
            while (true)
            {
                seed = rd.Next(1, 21);
                if (CheckID(seed))
                {
                    break;
                }
            }
            string bookName = string.Format("bookName-{0}", seed);
            Books book = new Books(seed.ToString("D3"), bookName);
            book.Date = DateTime.Today.AddDays(seed * -1);
            book.Price = seed;
            book.Author = string.Format("Author-{0}", seed);
            return book;
        }



        bool CheckID(int n)
        {
            bool b = true;
            foreach (DataGridViewRow r in dgvBook.Rows)
            {
                if (int.Parse(r.Cells[0].Value.ToString()) == n)
                {
                    b = false;
                    break;
                }
            }
            return b;
        }
        void ModifyBook(Books book)
        {
            int seed = rd.Next(1, 21);
            book.Name = string.Format("BookName-{0}", seed);
            book.Date = DateTime.Today.AddDays(seed);
            book.Price = seed;
            book.Author = string.Format("Author-{0}", seed);
        }
        void ShowBook(Books book, DataGridViewRow row)
        {
            row.Cells["ColID"].Value = book.ID;
            row.Cells["ColName"].Value = book.Name;
            row.Cells["ColPrice"].Value = book.Price;
            row.Cells["ColAuthor"].Value = book.Author;
            row.Cells["ColDate"].Value = book.Date.ToString("yyyy-MM-dd");
            row.Tag = book;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            this.Text = "�ǰ�ģʽ��ʹ��DataGridView";
            dgvBook.AllowUserToAddRows = false;
            dgvBook.AllowUserToDeleteRows = false;
            dgvBook.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvBook.MultiSelect = false;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (dgvBook.Rows.Count > 19)
            {
                MessageBox.Show("�����������ʾ20��ͼ���¼!", "����",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            Books book = CreateBooks();
            int NewIndex = dgvBook.Rows.Add();
            DataGridViewRow Newrow = dgvBook.Rows[NewIndex];
            ShowBook(book, Newrow);
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            if (dgvBook.CurrentRow != null)
            {
                dgvBook.Rows.Remove(dgvBook.CurrentRow);
            }
        }

        private void btnModi_Click(object sender, EventArgs e)
        {
            if (dgvBook.CurrentRow != null)
            {
                Books book = (Books)dgvBook.CurrentRow.Tag;
                if (book != null)
                {
                    ModifyBook(book);
                    ShowBook(book, dgvBook.CurrentRow);
                }
            }
        }
    }
}