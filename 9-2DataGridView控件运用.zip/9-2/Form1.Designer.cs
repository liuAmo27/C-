﻿namespace _9_2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnAdd = new Button();
            btnDel = new Button();
            btnModi = new Button();
            dgvBook = new DataGridView();
            ColID = new DataGridViewTextBoxColumn();
            ColName = new DataGridViewTextBoxColumn();
            ColAuthor = new DataGridViewTextBoxColumn();
            ColPrice = new DataGridViewTextBoxColumn();
            ColDate = new DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)dgvBook).BeginInit();
            SuspendLayout();
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(269, 60);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(86, 43);
            btnAdd.TabIndex = 0;
            btnAdd.Text = "添加新书";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnDel
            // 
            btnDel.Location = new Point(375, 60);
            btnDel.Name = "btnDel";
            btnDel.Size = new Size(89, 43);
            btnDel.TabIndex = 1;
            btnDel.Text = "删除所选";
            btnDel.UseVisualStyleBackColor = true;
            btnDel.Click += btnDel_Click;
            // 
            // btnModi
            // 
            btnModi.Location = new Point(485, 60);
            btnModi.Name = "btnModi";
            btnModi.Size = new Size(90, 43);
            btnModi.TabIndex = 2;
            btnModi.Text = "修改所选";
            btnModi.UseVisualStyleBackColor = true;
            btnModi.Click += btnModi_Click;
            // 
            // dgvBook
            // 
            dgvBook.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvBook.Columns.AddRange(new DataGridViewColumn[] { ColID, ColName, ColAuthor, ColPrice, ColDate });
            dgvBook.Location = new Point(79, 109);
            dgvBook.Name = "dgvBook";
            dgvBook.RowTemplate.Height = 25;
            dgvBook.Size = new Size(529, 186);
            dgvBook.TabIndex = 3;
            // 
            // ColID
            // 
            ColID.Frozen = true;
            ColID.HeaderText = "编号";
            ColID.Name = "ColID";
            // 
            // ColName
            // 
            ColName.HeaderText = "书名";
            ColName.Name = "ColName";
            // 
            // ColAuthor
            // 
            ColAuthor.HeaderText = "作者";
            ColAuthor.Name = "ColAuthor";
            // 
            // ColPrice
            // 
            ColPrice.HeaderText = "单价";
            ColPrice.Name = "ColPrice";
            // 
            // ColDate
            // 
            ColDate.HeaderText = "日期";
            ColDate.Name = "ColDate";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(dgvBook);
            Controls.Add(btnModi);
            Controls.Add(btnDel);
            Controls.Add(btnAdd);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dgvBook).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Button btnAdd;
        private Button btnDel;
        private Button btnModi;
        private DataGridView dgvBook;
        private DataGridViewTextBoxColumn ColID;
        private DataGridViewTextBoxColumn ColName;
        private DataGridViewTextBoxColumn ColAuthor;
        private DataGridViewTextBoxColumn ColPrice;
        private DataGridViewTextBoxColumn ColDate;
    }
}