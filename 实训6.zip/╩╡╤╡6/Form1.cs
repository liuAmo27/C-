namespace 实训6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        interface IEmployee
        {
            string Name
            { get; set; }
            bool Sex
            { get; set; }
            int Subsidy();
        }
        interface ITeacher : IEmployee
        {
            string Post
            { get; set; }
            new int Subsidy();
        }
        interface IWorker : IEmployee
        {
            int WorkingYear
            { get; set; }
            new int Subsidy();
        }
        class Teacher : ITeacher
        {
            string _name;
            bool _sex;
            string _post;
            public string Name
            {
                get { return _name; }
                set { _name = value; }
            }
            public bool Sex
            {
                get { return _sex; }
                set { _sex = value; }
            }
            public string Post
            {
                get { return _post; }
                set { _post = value; }
            }
            public int Subsidy()
            {
                int s = 0;
                switch (Post)
                {
                    case "教授":
                        s = 1200;
                        break;
                    case "讲师":
                        s = 500;
                        break;
                    case "副教授":
                        s = 800;
                        break;
                    case "助教":
                        s = 300;
                        break;
                }
                return s;
            }
        }
        class Worker : IWorker
        {
            string _name;
            bool _sex;
            int _year;
            public string Name
            {
                get { return _name; }
                set { _name = value; }
            }
            public bool Sex
            {
                get { return _sex; }
                set { _sex = value; }
            }
            public int WorkingYear
            {
                get { return _year; }
                set { _year = value; }
            }
            public int Subsidy()
            {
                return WorkingYear * 15;
            }
            public bool CheckNum(string num)
            {
                int y;
                if (!int.TryParse(num, out y))
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            public delegate void IsFalseDelegate();
            public event IsFalseDelegate IsFalse;
            public void ActiveEvent(string val)
            {
                if (int.Parse(val) > 50)
                {
                    IsFalse();
                }
            }
            public void BackError()
            {
                MessageBox.Show("工龄值输入可能有错误！", "提醒",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        // private void label1_Click(object sender, EventArgs e)
        //{

        //}

        //private void label6_Click(object sender, EventArgs e)
        //{

        //}

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Text = "接口和接口的继承";
            cboTeacherSex.Items.Add("男");
            cboTeacherSex.Items.Add("女");
            cboTeacherSex.Text = "男";
            ComboPost.Items.Add("教授");
            ComboPost.Items.Add("副教授");
            ComboPost.Items.Add("讲师");
            ComboPost.Items.Add("助教");
            ComboPost.Text = "教授";
            cboWorkerSex.Items.Add("男");
            cboWorkerSex.Items.Add("女");
            cboWorkerSex.Text = "男";
            lblTeacherInfo.Text = "";
            lblWorkerInfo.Text = "";
        }

        private void BtnTeacher_Click(object sender, EventArgs e)
        {
            if (txtTeacherName.Text == "")
            {
                MessageBox.Show("请输入教师姓名！", "出错",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            Teacher t = new Teacher();
            t.Post = ComboPost.Text;
            t.Name = txtTeacherName.Text;
            if (cboTeacherSex.Text == "男")
            {
                t.Sex = true;
            }
            else
            {
                t.Sex = false;
            }
            string s = t.Subsidy().ToString();
            string tsex;
            if (t.Sex)
            {
                tsex = "男";
            }
            else
            {
                tsex = "女";
            }
            lblTeacherInfo.Text = t.Name + "  " + tsex + "  " + t.Post
                + "  津贴：" + t.Subsidy().ToString();
        }

        private void btnWoker_Click(object sender, EventArgs e)
        {
            if (txtWorkerName.Text == "" || txtWorkingYear.Text == "")
            {
                MessageBox.Show("姓名和工龄值不能为空！", "出错",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            Worker w = new Worker();
            if (w.CheckNum(txtWorkingYear.Text) == false)
            {
                MessageBox.Show("工龄值数据格式不正确！", "出错",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            w.IsFalse += new Worker.IsFalseDelegate(w.BackError);
            w.ActiveEvent(txtWorkingYear.Text);
            w.WorkingYear = int.Parse(txtWorkingYear.Text);
            if (cboWorkerSex.Text == "男")
            {
                w.Sex = true;
            }
            else
            {
                w.Sex = false;
            }
            string s = w.Subsidy().ToString();
            string wsex;
            if (w.Sex)
            {
                wsex = "男";
            }
            else
            {
                wsex = "女";
            }
            lblWorkerInfo.Text = w.Name + "  " + wsex + "  "
                + w.WorkingYear.ToString() + "  津贴：" + w.Subsidy().ToString();

        }
    }
}