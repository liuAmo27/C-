﻿namespace 实训6
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tabControl1 = new TabControl();
            tabPage1 = new TabPage();
            BtnTeacher = new Button();
            txtTeacherName = new TextBox();
            ComboPost = new ComboBox();
            cboTeacherSex = new ComboBox();
            lblTeacherInfo = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            tabPage2 = new TabPage();
            btnWoker = new Button();
            txtWorkingYear = new TextBox();
            txtWorkerName = new TextBox();
            cboWorkerSex = new ComboBox();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            lblWorkerInfo = new Label();
            tabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            tabPage2.SuspendLayout();
            SuspendLayout();
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Location = new Point(42, 31);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(678, 380);
            tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(BtnTeacher);
            tabPage1.Controls.Add(txtTeacherName);
            tabPage1.Controls.Add(ComboPost);
            tabPage1.Controls.Add(cboTeacherSex);
            tabPage1.Controls.Add(lblTeacherInfo);
            tabPage1.Controls.Add(label3);
            tabPage1.Controls.Add(label2);
            tabPage1.Controls.Add(label1);
            tabPage1.Location = new Point(4, 26);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(670, 350);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "教师";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // BtnTeacher
            // 
            BtnTeacher.Location = new Point(376, 175);
            BtnTeacher.Name = "BtnTeacher";
            BtnTeacher.Size = new Size(145, 56);
            BtnTeacher.TabIndex = 15;
            BtnTeacher.Text = "确定";
            BtnTeacher.UseVisualStyleBackColor = true;
            BtnTeacher.Click += BtnTeacher_Click;
            // 
            // txtTeacherName
            // 
            txtTeacherName.Location = new Point(153, 55);
            txtTeacherName.Name = "txtTeacherName";
            txtTeacherName.Size = new Size(100, 23);
            txtTeacherName.TabIndex = 14;
            // 
            // ComboPost
            // 
            ComboPost.FormattingEnabled = true;
            ComboPost.Location = new Point(153, 133);
            ComboPost.Name = "ComboPost";
            ComboPost.Size = new Size(121, 25);
            ComboPost.TabIndex = 13;
            // 
            // cboTeacherSex
            // 
            cboTeacherSex.FormattingEnabled = true;
            cboTeacherSex.Location = new Point(376, 52);
            cboTeacherSex.Name = "cboTeacherSex";
            cboTeacherSex.Size = new Size(121, 25);
            cboTeacherSex.TabIndex = 12;
            // 
            // lblTeacherInfo
            // 
            lblTeacherInfo.AutoSize = true;
            lblTeacherInfo.Location = new Point(166, 214);
            lblTeacherInfo.Name = "lblTeacherInfo";
            lblTeacherInfo.Size = new Size(43, 17);
            lblTeacherInfo.TabIndex = 11;
            lblTeacherInfo.Text = "label4";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(102, 138);
            label3.Name = "label3";
            label3.Size = new Size(32, 17);
            label3.TabIndex = 10;
            label3.Text = "职称";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(338, 58);
            label2.Name = "label2";
            label2.Size = new Size(32, 17);
            label2.TabIndex = 9;
            label2.Text = "性别";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(102, 55);
            label1.Name = "label1";
            label1.Size = new Size(32, 17);
            label1.TabIndex = 8;
            label1.Text = "姓名";
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(btnWoker);
            tabPage2.Controls.Add(txtWorkingYear);
            tabPage2.Controls.Add(txtWorkerName);
            tabPage2.Controls.Add(cboWorkerSex);
            tabPage2.Controls.Add(label5);
            tabPage2.Controls.Add(label6);
            tabPage2.Controls.Add(label7);
            tabPage2.Controls.Add(lblWorkerInfo);
            tabPage2.Location = new Point(4, 26);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(670, 350);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "工人";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // btnWoker
            // 
            btnWoker.Location = new Point(422, 175);
            btnWoker.Name = "btnWoker";
            btnWoker.Size = new Size(131, 87);
            btnWoker.TabIndex = 19;
            btnWoker.Text = "确定";
            btnWoker.UseVisualStyleBackColor = true;
            btnWoker.Click += btnWoker_Click;
            // 
            // txtWorkingYear
            // 
            txtWorkingYear.Location = new Point(190, 148);
            txtWorkingYear.Name = "txtWorkingYear";
            txtWorkingYear.Size = new Size(100, 23);
            txtWorkingYear.TabIndex = 18;
            // 
            // txtWorkerName
            // 
            txtWorkerName.Location = new Point(190, 61);
            txtWorkerName.Name = "txtWorkerName";
            txtWorkerName.Size = new Size(100, 23);
            txtWorkerName.TabIndex = 17;
            // 
            // cboWorkerSex
            // 
            cboWorkerSex.FormattingEnabled = true;
            cboWorkerSex.Location = new Point(409, 64);
            cboWorkerSex.Name = "cboWorkerSex";
            cboWorkerSex.Size = new Size(121, 25);
            cboWorkerSex.TabIndex = 16;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(126, 61);
            label5.Name = "label5";
            label5.Size = new Size(32, 17);
            label5.TabIndex = 15;
            label5.Text = "姓名";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(360, 64);
            label6.Name = "label6";
            label6.Size = new Size(32, 17);
            label6.TabIndex = 14;
            label6.Text = "性别";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(126, 154);
            label7.Name = "label7";
            label7.Size = new Size(32, 17);
            label7.TabIndex = 13;
            label7.Text = "工龄";
            // 
            // lblWorkerInfo
            // 
            lblWorkerInfo.AutoSize = true;
            lblWorkerInfo.Location = new Point(126, 223);
            lblWorkerInfo.Name = "lblWorkerInfo";
            lblWorkerInfo.Size = new Size(43, 17);
            lblWorkerInfo.TabIndex = 12;
            lblWorkerInfo.Text = "label8";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(tabControl1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            tabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TabControl tabControl1;
        private TabPage tabPage1;
        private Button BtnTeacher;
        private TextBox txtTeacherName;
        private ComboBox ComboPost;
        private ComboBox cboTeacherSex;
        private Label lblTeacherInfo;
        private Label label3;
        private Label label2;
        private Label label1;
        private TabPage tabPage2;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label lblWorkerInfo;
        private Button btnWoker;
        private TextBox txtWorkingYear;
        private TextBox txtWorkerName;
        private ComboBox cboWorkerSex;
    }
}