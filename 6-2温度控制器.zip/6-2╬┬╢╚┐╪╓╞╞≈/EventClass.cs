﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _6_2
{
    internal class EventClass
    {
        public delegate void TempAlarmDelegate();
        public event TempAlarmDelegate TempAlarm;
        public void ActiveEvent()
        {
            if (TempAlarm != null)
            {
                TempAlarm();
            }
        }
    }

}
