namespace _6_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int temp = 0;
        private void Form1_Load(object sender, EventArgs e)
        {
            this.Text = "�¶ȿ�����";
            label1.Text = "��ǰ�¶�Ϊ��" + temp + "��";
            timer1.Interval = 1000;
            timer1.Enabled = true;
        }
        public void TempLower()
        {
            temp = temp - 3;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            temp += 1;
            label1.Text = "��ǰ�¶�Ϊ��" + temp + "��";
            if (temp == 10)
            {
                EventClass EC = new EventClass();
                EC.TempAlarm += new EventClass.TempAlarmDelegate(TempLower);
                EC.ActiveEvent();
            }
        }
    }
}