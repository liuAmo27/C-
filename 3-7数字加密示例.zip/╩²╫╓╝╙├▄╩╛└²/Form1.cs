﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 数字加密示例//34朱泓磊
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string x;
        private void Form1_Load(object sender, EventArgs e)
        {
            label1.Text = "您实际输入的是：";
            this.Text = "数字加密示例";
        }
        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            x = textBox1.Text;
            if ((int)e.KeyCode != (int)Keys.Back && (e.KeyValue >= 48 && e.KeyValue <= 57 || e.KeyValue >= 96 && e.KeyValue <= 105))
            {
                if (e.KeyValue < 96)
                {
                    label1.Text = label1.Text + (char)e.KeyValue;
                }
                else
                {
                    label1.Text = label1.Text + (char)(e.KeyValue - 48);
                }
            }
            else if ((int)e.KeyCode == (int)Keys.Back)
            {
                if (textBox1.Text != "")
                {
                    label1.Text = label1.Text.Remove(label1.Text.Length - 1);
                }
            }
        }
        private void textBox1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Control && e.Shift && e.KeyValue == 35)
            {
                this.Close();
            }
            if ((int)e.KeyCode != (char)Keys.Back && (int)e.KeyCode != (char)Keys.Enter)
            {
                switch ((int)e.KeyCode)
                {
                    case (char)Keys.D1:
                    case (char)Keys.NumPad1: textBox1.Text = x + "!"; break;
                    case (char)Keys.D2:
                    case (char)Keys.NumPad2: textBox1.Text = x + "&"; break;
                    case (char)Keys.D3:
                    case (char)Keys.NumPad3: textBox1.Text = x + "#"; break;
                    case (char)Keys.D4:
                    case (char)Keys.NumPad4: textBox1.Text = x + "/"; break;
                    case (char)Keys.D5:
                    case (char)Keys.NumPad5: textBox1.Text = x + ")"; break;
                    case (char)Keys.D6:
                    case (char)Keys.NumPad6: textBox1.Text = x + "$"; break;
                    case (char)Keys.D7:
                    case (char)Keys.NumPad7: textBox1.Text = x + "*"; break;
                    case (char)Keys.D8:
                    case (char)Keys.NumPad8: textBox1.Text = x + "@"; break;
                    case (char)Keys.D9:
                    case (char)Keys.NumPad9: textBox1.Text = x + "\\"; break;
                    case (char)Keys.D0:
                    case (char)Keys.NumPad0: textBox1.Text = x + "+"; break;
                }
                textBox1.SelectionStart = textBox1.TextLength;
            }
            if ((int)e.KeyCode == (int)Keys.Enter)
            {
                if (MessageBox.Show("您确实要退出程序吗？", "确认退出", MessageBoxButtons.OKCancel, MessageBoxIcon.Information) == DialogResult.OK)
                {
                    this.Close();
                }
            }
        }

    }
}
