namespace _7_4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        class NewComparer : IComparer<int>
        {
            public int Compare(int x, int y)
            {
                int AbsX=Math.Abs(x);
                int AbsY=Math.Abs(y);
                return AbsX - AbsY; 
            }
        }
        string Display<T>(List<int> lst)
        {
            string Result = "";
            foreach (int val in lst)
            {
                Result += val.ToString()+" ";
            }
            return Result;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            this.Text = "IComparer<T>���ͽӿ�Ӧ��ʾ��";
            label1.Text = "";
            int[] ary = { 9, 8, -11, 10, -3, 2 };
            List<int> intlist = new List<int>();
            intlist.AddRange(ary);
            label1.Text="����ǰ��"+Display<int>(intlist)+"\n\n";
            intlist.Sort();
            label1.Text = label1.Text + "Ĭ�Ϸ�ʽ����" + Display<int>(intlist) + "\n\n";
            NewComparer comp = new NewComparer();
            intlist.Sort(comp);
            label1.Text = label1.Text + "������ֵ����" + Display<int>(intlist) + "\n\n";
            intlist.Reverse();
            label1.Text = label1.Text + "Ԫ�ط�ת��" + Display<int>(intlist) + "\n\n";
            intlist.Sort(2, 3, comp);
            label1.Text = label1.Text + "��������" + Display<int>(intlist);
        }
    }
}